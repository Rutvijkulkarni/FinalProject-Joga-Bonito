package com.example.finalproject;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class ManagerList extends ArrayAdapter<Manager> {

    private Activity context;
    private List<Manager> managerList;

    public ManagerList(Activity context, List<Manager> managerList){
        super(context, R.layout.listmanager_layout, managerList);
        this.context=context;
        this.managerList=managerList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem  = inflater.inflate(R.layout.listmanager_layout, null, true);

        TextView textViewName = (TextView) listViewItem.findViewById(R.id.textViewName);
        TextView textViewEmail = (TextView) listViewItem.findViewById(R.id.textViewEmail);
        TextView textViewFormation = (TextView) listViewItem.findViewById(R.id.textViewFormation);
        TextView textViewCounty = (TextView) listViewItem.findViewById(R.id.textViewCounty);

        Manager manager = managerList.get(position);

        textViewName.setText(manager.getManagerName());
        textViewEmail.setText(manager.getManagerEmail());
        textViewFormation.setText(manager.getManagerFormation());
        textViewCounty.setText(manager.getManagerCounty());

        return listViewItem;
    }
}

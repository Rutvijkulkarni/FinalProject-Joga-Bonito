package com.example.finalproject;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class PlayerList extends ArrayAdapter<Player> {

    private Activity context;
    private List<Player> playerList;

    public PlayerList(Activity context, List<Player> playerList){
        super(context, R.layout.listplayer_layout, playerList);
        this.context = context;
        this.playerList = playerList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();

        View listViewItem = inflater.inflate(R.layout.listplayer_layout, null, true);

        TextView textViewName = (TextView) listViewItem.findViewById(R.id.textViewName);
        TextView textViewEmail = (TextView) listViewItem.findViewById(R.id.textViewEmail);
        TextView textViewPosition = (TextView) listViewItem.findViewById(R.id.textViewPosition);
        TextView textViewCounty = (TextView) listViewItem.findViewById(R.id.textViewCounty);

        Player player = playerList.get(position);

        textViewName.setText(player.getPlayerName());
        textViewEmail.setText(player.getPlayerEmail());
        textViewPosition.setText(player.getPlayerPosition());
        textViewCounty.setText(player.getPlayerCounty());

        return listViewItem;
    }
}

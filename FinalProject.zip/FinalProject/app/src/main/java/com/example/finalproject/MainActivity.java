package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {
    //Variable for setting duration of Splash screen.
    private static int SPLASH_TIME = 6000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Creates delay allowing the splash screen to stay as long as the variable declared above.
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //Instruction to load new activity after splash screen duration.
                Intent i = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(i);
                finish();
            }
        }, SPLASH_TIME);
    }
}
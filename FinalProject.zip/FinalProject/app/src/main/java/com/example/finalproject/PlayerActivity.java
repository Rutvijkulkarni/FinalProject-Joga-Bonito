package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class PlayerActivity extends AppCompatActivity {

    EditText editTextPlayerName;
    EditText editTextPlayerEmail;
    EditText editTextPlayerPosition;
    Spinner spinnerCounty;
    Button btnAdd;
    Button btnBack;
    Button btnContact;

    DatabaseReference databasePlayers;

    ListView listViewPlayers;
    List<Player> playerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        databasePlayers = FirebaseDatabase.getInstance().getReference("Players");

        editTextPlayerName = (EditText) findViewById(R.id.editTextName);
        editTextPlayerEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextPlayerPosition = (EditText) findViewById(R.id.editTextPosition);

        btnAdd = (Button) findViewById(R.id.btnAddPlayer);
        btnBack = (Button) findViewById(R.id.btnBack);
        btnContact = (Button) findViewById(R.id.btnContact);
        spinnerCounty = (Spinner) findViewById(R.id.spinnerCounty);

        listViewPlayers = (ListView) findViewById(R.id.listViewPlayer);
        playerList = new ArrayList<>();

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddPlayer();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendToHome = new Intent(PlayerActivity.this,HomeActivity.class);
                startActivity(sendToHome);
            }
        });

        btnContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("text/plain");
                startActivity(emailIntent);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();

        databasePlayers.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                playerList.clear();

                for(DataSnapshot playerSnapshot: snapshot.getChildren()){
                    Player player = playerSnapshot.getValue(Player.class);
                    playerList.add(player);
                }

                PlayerList adapter = new PlayerList(PlayerActivity.this, playerList);
                listViewPlayers.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void AddPlayer(){
        String name = editTextPlayerName.getText().toString().trim();
        String email = editTextPlayerEmail.getText().toString();
        String position = editTextPlayerPosition.getText().toString().trim();
        String county = spinnerCounty.getSelectedItem().toString();

        if(!TextUtils.isEmpty(name)){

            String id = databasePlayers.push().getKey();

            Player player = new Player(id, name, email, position, county);

            databasePlayers.child(id).setValue(player);

            Toast.makeText(this, "Player Added.", Toast.LENGTH_LONG).show();

        }else{
            Toast.makeText(this, "Please enter name.", Toast.LENGTH_LONG).show();
        }
    }

}
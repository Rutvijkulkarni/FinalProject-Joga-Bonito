package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    EditText emailID, password;
    Button signInBtn, registerBtn;
    FirebaseAuth authFirebase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        authFirebase = authFirebase.getInstance();
        emailID = findViewById(R.id.email);
        password = findViewById(R.id.pwd);
        registerBtn = findViewById(R.id.manager);
        signInBtn = findViewById(R.id.player);

        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = emailID.getText().toString();
                String pwd = password.getText().toString();

                if(email.isEmpty()){
                    //Error message if email not entered
                    emailID.setError("Please Enter Email ID");
                    emailID.requestFocus();
                }
                else if(pwd.isEmpty()){
                    //Error message if password not entered
                    password.setError("Please Enter Password");
                    password.requestFocus();
                }
                else if(email.isEmpty() && pwd.isEmpty()){
                    //Alerts user if fields are empty
                    Toast.makeText(RegisterActivity.this,"Invalid, Fields are Empty.",Toast.LENGTH_SHORT).show();
                }
                else if(!(email.isEmpty() && pwd.isEmpty())){
                    //Firebase create user method to create email and password.
                    authFirebase.createUserWithEmailAndPassword(email, pwd).addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(!task.isSuccessful()){
                                //Alerts user if registration was not successful.
                                Toast.makeText(RegisterActivity.this,"Registration Unsuccessful, Please try again.",Toast.LENGTH_SHORT).show();
                            }
                            else {
                                //If registration is successful, redirects user to Home page of the application.
                                startActivity(new Intent(RegisterActivity.this,HomeActivity.class));
                            }
                        }
                    });
                }
                else {
                    //Global alert if registration unsuccessful
                    Toast.makeText(RegisterActivity.this,"Registration Error.",Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Sign In Button function if user already has already registered. Redirects user to LoginActivity page
        signInBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });
    }
}
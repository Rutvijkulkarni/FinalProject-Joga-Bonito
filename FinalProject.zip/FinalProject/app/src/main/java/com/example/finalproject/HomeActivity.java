package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.content.Intent;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {
    Button managerBtn;
    Button playerBtn;
    Button logoutBtn;
    FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        managerBtn = findViewById(R.id.manager);
        playerBtn = findViewById(R.id.player);
        logoutBtn = findViewById(R.id.logout);

        //Logout Button code, sends user back to login screen.
        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firebaseAuth.getInstance().signOut();
                Intent backToLogin = new Intent(HomeActivity.this,LoginActivity.class);
                startActivity(backToLogin);
            }
        });

        //Redirects user to ManagerActivity
        managerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendToManager = new Intent(HomeActivity.this,ManagerActivity.class);
                startActivity(sendToManager);
            }
        });

        //Redirects user to PlayerActivity
        playerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendToPlayer = new Intent(HomeActivity.this,PlayerActivity.class);
                startActivity(sendToPlayer);
            }
        });
    }
}
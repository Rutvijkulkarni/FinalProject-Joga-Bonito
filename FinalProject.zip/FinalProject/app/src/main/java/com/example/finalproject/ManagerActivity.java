package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ManagerActivity extends AppCompatActivity {

    EditText editTextManagerName;
    EditText editTextManagerEmail;
    EditText editTextManagerFormation;
    Spinner spinnerCounty;
    Button btnAdd;
    Button btnBack;
    Button btnContact;

    DatabaseReference databaseManagers;

    ListView listViewManager;

    List<Manager> managerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager);

        databaseManagers = FirebaseDatabase.getInstance().getReference("Managers");

        editTextManagerName = (EditText) findViewById(R.id.editTextName);
        editTextManagerEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextManagerFormation = (EditText) findViewById(R.id.editTextFormation);

        btnAdd = (Button) findViewById(R.id.btnAddManager);
        btnBack = (Button) findViewById(R.id.backBtn);
        btnContact = (Button) findViewById(R.id.btnContact);
        spinnerCounty = (Spinner) findViewById(R.id.spinnerCounty);

        listViewManager = (ListView) findViewById(R.id.listViewManager);

        managerList = new ArrayList<>();

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddManager();
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendToPlayer = new Intent(ManagerActivity.this,HomeActivity.class);
                startActivity(sendToPlayer);
            }
        });

        btnContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setType("text/plain");
                startActivity(emailIntent);
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();

        databaseManagers.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                managerList.clear();

                for(DataSnapshot managerSnapshot: snapshot.getChildren()){
                    Manager manager = managerSnapshot.getValue(Manager.class);
                    managerList.add(manager);
                }

                ManagerList adapter = new ManagerList(ManagerActivity.this, managerList);
                listViewManager.setAdapter(adapter);

            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
    }

    private void AddManager(){
        String name = editTextManagerName.getText().toString().trim();
        String email = editTextManagerEmail.getText().toString();
        String formation = editTextManagerFormation.getText().toString().trim();
        String county = spinnerCounty.getSelectedItem().toString();

        if(!TextUtils.isEmpty(name)){

            String id = databaseManagers.push().getKey();

            Manager manager = new Manager(id, name, email, formation, county);

            databaseManagers.child(id).setValue(manager);

            Toast.makeText(this, "Manager Added.", Toast.LENGTH_LONG).show();

        }else{
            Toast.makeText(this, "Please enter name.", Toast.LENGTH_LONG).show();
        }
    }
}
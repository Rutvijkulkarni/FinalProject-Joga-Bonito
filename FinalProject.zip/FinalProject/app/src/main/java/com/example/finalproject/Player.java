package com.example.finalproject;

public class Player {
    String playerId;
    String playerName;
    String playerEmail;
    String playerPosition;
    String playerCounty;

    public Player(){

    }

    public Player(String playerId, String playerName, String playerEmail, String playerPosition, String playerCounty) {
        this.playerId = playerId;
        this.playerName = playerName;
        this.playerEmail = playerEmail;
        this.playerPosition = playerPosition;
        this.playerCounty = playerCounty;
    }

    public String getPlayerId() {
        return playerId;
    }

    public String getPlayerName() {
        return playerName;
    }

    public String getPlayerEmail() {
        return playerEmail;
    }

    public String getPlayerPosition() {
        return playerPosition;
    }

    public String getPlayerCounty() {
        return playerCounty;
    }
}

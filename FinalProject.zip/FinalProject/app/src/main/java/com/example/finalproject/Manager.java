package com.example.finalproject;

public class Manager {

    String managerId;
    String managerName;
    String managerEmail;
    String managerFormation;
    String managerCounty;

    public Manager(){

    }

    public Manager(String managerId, String managerName, String managerEmail, String managerFormation, String managerCounty) {
        this.managerId = managerId;
        this.managerName = managerName;
        this.managerEmail = managerEmail;
        this.managerFormation = managerFormation;
        this.managerCounty = managerCounty;
    }

    public String getManagerId() {
        return managerId;
    }

    public String getManagerName() {
        return managerName;
    }

    public String getManagerEmail() {
        return managerEmail;
    }

    public String getManagerFormation() {
        return managerFormation;
    }

    public String getManagerCounty() {
        return managerCounty;
    }
}
